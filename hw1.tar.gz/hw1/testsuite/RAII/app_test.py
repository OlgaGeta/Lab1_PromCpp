import subprocess

def test_write_and_read_text(language, text):
    
    input_lines = [
        'file.txt',
        'w',
        text,
        'y',
        'file.txt',
        'r'
    ]

    
    process = subprocess.Popen(['bin/main_RAII'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate('\n'.join(input_lines).encode())

    
    with open('file.txt', 'r', encoding='utf-8') as f:
        assert f.read() == text

   
    print(f'Test for writing and reading text in {language} passed successfully.')


test_cases = [
    ('English', 'This is a test text'),
    ('French', 'Ceci est un texte de test'),
    ('Spanish', 'Este es un texto de prueba'),
    ('Russian', 'Это тестовый текст'),
    ('Chinese', '这是一个测试文本')
]


for language, text in test_cases:
    test_write_and_read_text(language, text)
